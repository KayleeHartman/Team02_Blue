//
//  BedroomViewController.swift
//  Team02_Blue_Todd
//
//  Created by Haines D Todd on 11/18/17.
//  Copyright © 2017 Haines D Todd. All rights reserved.
//

import UIKit
import AVFoundation

class BedroomViewController: UIViewController {
    
    var background: UIImageView?
    var cleanupItems: [CleanupItem] = []
    
    @IBOutlet weak var BedroomCountdown: UILabel!
    var count = 30
    var model: Model?
    var BedroomSoundEffects:AVAudioPlayer?
    private var musicpath: String = "null"
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadCleanupItemImages() //create UIImages from the assets related to the bedroom and initialize the cleanupItems array
        model = Model(itemsToClean: cleanupItems.count, cleanupItems: cleanupItems) //initialize the model by passing all of the cleanup items into it
        
        //the background is the only image that needs a tapGestureRecognizer attached to it
        background?.isUserInteractionEnabled = true
        background?.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(itemTapped)))
        var timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(TimerUpdate), userInfo: nil, repeats: true)
        
    }
    
    @objc func itemTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        let touchPoint = tapGestureRecognizer.location(in: background)
        model?.update(coordinates: touchPoint)
    }
    
    func playsound(musicpath music:String)
    {
        //music = "chemicalSpill.mp3"
        let path = Bundle.main.path(forResource: music, ofType:nil)!
        let url = URL(fileURLWithPath: path)
        do {
            BedroomSoundEffects = try AVAudioPlayer(contentsOf: url)
            BedroomSoundEffects?.play()
        } catch {
            // couldn't load file :(
        }
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    //programmatically create UIImageViews for all of the images used for this room
    //the background image is placed alone and will have a TapGestureRecognizer attached to it
    //it is important that all of the images have the same size and location within the main view
    
    //cleanup items are placed in an instance of the CleanupItem class along
    //the CleanupItem class accepts the image for the dirty version of the item and the clean version (i.e. unmadeBed.png and madeBed.png)
    //if the dirty version of the item has no compliment, nil is passed into the CleanupItem constructor
    func loadCleanupItemImages() {
        let width = view.frame.width - 250
        let height = view.frame.height - 250
        
        background = createImageViewFromAsset(assetName: "Bedroom_Background.png", width: width, height: height)
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_OnePillow.png", width: width, height: height),
                                        viewWhenClean: createImageViewFromAsset(assetName: "Bedroom_AllPillows.png", width: width, height: height),
                                        identifier: "pillow fight leftovers",musicpath: "pillow.mp3"))
                                        //playsound(musicpath: "chemicalSpill.mp3")
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_DirtyTowel.png", width: width, height: height),
                                        viewWhenClean: nil,
                                        identifier: "dirty towel",musicpath: "lamp.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_FallenLamp.png", width: width, height: height),
                                        viewWhenClean: createImageViewFromAsset(assetName: "Bedroom_Lamp.png", width: width, height: height),
                                        identifier: "sleeping lamp",musicpath: "lamp.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_FlippedRug.png", width: width, height: height),
                                        viewWhenClean: createImageViewFromAsset(assetName: "Bedroom_Rug.png", width: width, height: height),
                                        identifier: "rug that is flipping you off",musicpath: "rug.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_FullTrashcan.png", width: width, height: height),
                                        viewWhenClean: nil,
                                        identifier: "trash full of can",musicpath: "trash.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_UnmadeBed.png", width: width, height: height),
                                        viewWhenClean: createImageViewFromAsset(assetName: "Bedroom_MadeBed.png", width: width, height: height),
                                        identifier: "bootcamp seargent would not approve",musicpath: "lamp.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_WindowSmudges.png", width: width, height: height),
                                        viewWhenClean: nil,
                                        identifier: "window stains of unknown origin",musicpath: "glass.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_SpilledDrink.png", width: width, height: height),
                                        viewWhenClean: nil,
                                        identifier: "chemical spill (most likely Ricin)",musicpath: "chemicalSpill.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_FullStool.png", width: width, height: height),
                                        viewWhenClean: createImageViewFromAsset(assetName: "Bedroom_Stool.png", width: width, height: height),
                                        identifier: "ottomon is evolving",musicpath: "stool.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_Remote.png", width: width, height: height),
                                        viewWhenClean: nil,
                                        identifier: "RF transmitting device does not meet FCC regulations",musicpath: "lamp.mp3"))
        
        cleanupItems.append(CleanupItem(viewWhenDirty: createImageViewFromAsset(assetName: "Bedroom_OpenNightstand.png", width: width, height: height),
                                        viewWhenClean: nil,
                                        identifier: "lock out tagout protocol not followed",musicpath: "closet.mp3"))
    }
    
    //create a UIImageView and place it in the center of the screen with specified height and width
    func createImageViewFromAsset (assetName: String, width: CGFloat, height: CGFloat) -> UIImageView {
        let imageView = UIImageView(image: UIImage(named: assetName))
        imageView.contentMode = .scaleAspectFit
        imageView.frame = CGRect(x: view.center.x-(width/2), y: view.center.y-(height/2), width: width, height: height)
        self.view.addSubview(imageView)
        
        return imageView
    }
    
    @objc func TimerUpdate()
    {
       
        if(count > 0) {
            count = count - 1
            BedroomCountdown.text = String(count)
            
            if(count < 6)
            {
                //count = count - 1
                BedroomCountdown.text = String(count)
                BedroomCountdown.textColor = UIColor.red
                playsound(musicpath: "timeout.mp3")
                
                
            }
            
        }
    }
    
    
}

